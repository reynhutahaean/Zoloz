//
//  Zoloz.h
//  Zoloz
//
//  Created by Reynaldo Cristinus Hutahaean on 14/08/23.
//

#import <Foundation/Foundation.h>

//! Project version number for Zoloz.
FOUNDATION_EXPORT double ZolozVersionNumber;

//! Project version string for Zoloz.
FOUNDATION_EXPORT const unsigned char ZolozVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Zoloz/PublicHeader.h>


